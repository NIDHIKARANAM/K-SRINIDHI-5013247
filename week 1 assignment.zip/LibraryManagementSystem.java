package deepskilling;

import java.util.Arrays;
import java.util.Scanner;

class Book {
    int bookId;
    String title;
    String author;

    public Book(int bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
    }

    @Override
    public String toString() {
        return "Book{" +
                "bookId=" + bookId +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                '}';
    }
}

public class LibraryManagementSystem {
    private Book[] books;

    public LibraryManagementSystem(Book[] books) {
        this.books = books;
    }

    public Book linearSearch(String title) {
        for (Book book : books) {
            if (book.title.equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    public Book binarySearch(String title) {
        int left = 0;
        int right = books.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = books[mid].title.compareToIgnoreCase(title);
            if (comparison == 0) {
                return books[mid];
            }
            if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of books: ");
        int numberOfBooks = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Book[] books = new Book[numberOfBooks];
        for (int i = 0; i < numberOfBooks; i++) {
            System.out.print("Enter book ID: ");
            int bookId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter book title: ");
            String title = scanner.nextLine();

            System.out.print("Enter book author: ");
            String author = scanner.nextLine();

            books[i] = new Book(bookId, title, author);
        }

        Arrays.sort(books, (b1, b2) -> b1.title.compareToIgnoreCase(b2.title));

        LibraryManagementSystem system = new LibraryManagementSystem(books);

        while (true) {
            System.out.println("1. Linear Search");
            System.out.println("2. Binary Search");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            if (choice == 1) {
                System.out.print("Enter book title to search: ");
                String title = scanner.nextLine();
                Book book = system.linearSearch(title);
                if (book != null) {
                    System.out.println(book);
                } else {
                    System.out.println("Book not found.");
                }
            } else if (choice == 2) {
                System.out.print("Enter book title to search: ");
                String title = scanner.nextLine();
                Book book = system.binarySearch(title);
                if (book != null) {
                    System.out.println(book);
                } else {
                    System.out.println("Book not found.");
                }
            } else if (choice == 3) {
                break;
            } else {
                System.out.println("Invalid option. Try again.");
            }
        }
        scanner.close();
    }
}
