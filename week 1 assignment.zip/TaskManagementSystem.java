package deepskilling;

import java.util.Scanner;

class Task {
    int taskId;
    String taskName;
    String status;
    Task next;

    public Task(int taskId, String taskName, String status) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.status = status;
        this.next = null;
    }

    @Override
    public String toString() {
        return "Task{" +
                "taskId=" + taskId +
                ", taskName='" + taskName + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}

public class TaskManagementSystem {
    private Task head;

    public TaskManagementSystem() {
        head = null;
    }

    public void addTask(Task task) {
        if (head == null) {
            head = task;
        } else {
            Task current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = task;
        }
    }

    public Task searchTask(int taskId) {
        Task current = head;
        while (current != null) {
            if (current.taskId == taskId) {
                return current;
            }
            current = current.next;
        }
        return null;
    }

    public void traverseTasks() {
        Task current = head;
        while (current != null) {
            System.out.println(current);
            current = current.next;
        }
    }

    public void deleteTask(int taskId) {
        if (head == null) {
            System.out.println("Task not found.");
            return;
        }
        if (head.taskId == taskId) {
            head = head.next;
            return;
        }
        Task current = head;
        while (current.next != null && current.next.taskId != taskId) {
            current = current.next;
        }
        if (current.next != null) {
            current.next = current.next.next;
        } else {
            System.out.println("Task not found.");
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TaskManagementSystem system = new TaskManagementSystem();

        while (true) {
            System.out.println("1. Add Task");
            System.out.println("2. Search Task");
            System.out.println("3. Traverse Tasks");
            System.out.println("4. Delete Task");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            if (choice == 1) {
                System.out.print("Task ID: ");
                int id = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Task Name: ");
                String name = scanner.nextLine();
                System.out.print("Status: ");
                String status = scanner.nextLine();
                system.addTask(new Task(id, name, status));
            } else if (choice == 2) {
                System.out.print("Task ID to search: ");
                int id = scanner.nextInt();
                Task task = system.searchTask(id);
                if (task != null) {
                    System.out.println(task);
                } else {
                    System.out.println("Task not found.");
                }
            } else if (choice == 3) {
                system.traverseTasks();
            } else if (choice == 4) {
                System.out.print("Task ID to delete: ");
                int id = scanner.nextInt();
                system.deleteTask(id);
            } else if (choice == 5) {
                break;
            } else {
                System.out.println("Invalid option. Try again.");
            }
        }
        scanner.close();
    }
}

