package deepskilling;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

class Item {
    private int itemId;
    private String itemName;
    private String category;

    public Item(int itemId, String itemName, String category) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.category = category;
    }

    public int getItemId() {
        return itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public String getCategory() {
        return category;
    }

    @Override
    public String toString() {
        return "Item{" +
                "itemId=" + itemId +
                ", itemName='" + itemName + '\'' +
                ", category='" + category + '\'' +
                '}';
    }
}

public class ex2 {

    public static Item linearSearch(Item[] items, String targetName) {
        for (Item item : items) {
            if (item.getItemName().equalsIgnoreCase(targetName)) {
                return item;
            }
        }
        return null;
    }

    public static Item binarySearch(Item[] items, String targetName) {
        int low = 0;
        int high = items.length - 1;

        while (low <= high) {
            int mid = (low + high) / 2;
            Item midItem = items[mid];

            int comparison = midItem.getItemName().compareToIgnoreCase(targetName);
            if (comparison == 0) {
                return midItem;
            } else if (comparison < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the number of items:");
        int numberOfItems = scanner.nextInt();
        scanner.nextLine(); 

        Item[] items = new Item[numberOfItems];

        for (int i = 0; i < numberOfItems; i++) {
            System.out.println("Enter item ID:");
            int itemId = scanner.nextInt();
            scanner.nextLine(); 

            System.out.println("Enter item name:");
            String itemName = scanner.nextLine();

            System.out.println("Enter item category:");
            String category = scanner.nextLine();

            items[i] = new Item(itemId, itemName, category);
        }

        System.out.println("Enter the item name to search:");
        String targetName = scanner.nextLine();

        Item linearSearchResult = linearSearch(items, targetName);
        if (linearSearchResult != null) {
            System.out.println("Item found using Linear Search: " + linearSearchResult);
        } else {
            System.out.println("Item not found using Linear Search.");
        }

        Arrays.sort(items, Comparator.comparing(Item::getItemName));

        Item binarySearchResult = binarySearch(items, targetName);
        if (binarySearchResult != null) {
            System.out.println("Item found using Binary Search: " + binarySearchResult);
        } else {
            System.out.println("Item not found using Binary Search.");
        }

        scanner.close();
    }
}
